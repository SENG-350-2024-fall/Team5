const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname))); // Serve static files from the current directory

const dataFilePath = path.join(__dirname, 'triage_data.json');

// Existing processOrder endpoint for creating new applications
app.post('/processOrder', (req, res) => {
    const newData = req.body; // This will include name, symptoms, severity, and hasAllergies

    // Step 1: Read existing data from the file (or initialize as an empty array)
    let existingData = [];
    if (fs.existsSync(dataFilePath)) {
        const fileContent = fs.readFileSync(dataFilePath, 'utf8');
        existingData = fileContent ? JSON.parse(fileContent) : [];
    }

    // Step 2: Create a new triage object
    const triageObject = {
        name: newData.name,         // Use the name field from the request
        symptoms: newData.symptoms,
        severity: newData.severity,
        hasAllergies: newData.hasAllergies
    };

    // Step 3: Add the new triage object to the existing array
    existingData.push(triageObject);

    // Step 4: Write the updated array back to the file
    fs.writeFileSync(dataFilePath, JSON.stringify(existingData, null, 2));

    res.json({ status: 'resolved', message: 'Data saved successfully!' });
});

// New endpoint for updating existing applications
app.post('/updateApplication', (req, res) => {
    const { name, data } = req.body; // Update to take the name

    // Step 1: Read existing data from the file
    let existingData = [];
    if (fs.existsSync(dataFilePath)) {
        const fileContent = fs.readFileSync(dataFilePath, 'utf8');
        existingData = fileContent ? JSON.parse(fileContent) : [];
    }

    // Step 2: Find the application by name
    const appIndex = existingData.findIndex(app => app.name === name);

    // Step 3: Update the specific application if it exists
    if (appIndex !== -1) {
        existingData[appIndex] = {
            name: data.name,
            symptoms: data.symptoms,
            severity: data.severity,
            hasAllergies: data.hasAllergies
        }; // Update the application at the found index

        // Step 4: Write the updated array back to the file
        fs.writeFileSync(dataFilePath, JSON.stringify(existingData, null, 2));

        res.json({ status: 'resolved', message: 'Application updated successfully!' });
    } else {
        res.json({ status: 'error', message: 'Application not found.' });
    }
});

// New endpoint for deleting applications
app.delete('/deleteApplication', (req, res) => {
    const { name } = req.body; // Get the name from the request body

    // Step 1: Read existing data from the file
    let existingData = [];
    if (fs.existsSync(dataFilePath)) {
        const fileContent = fs.readFileSync(dataFilePath, 'utf8');
        existingData = fileContent ? JSON.parse(fileContent) : [];
    }

    // Step 2: Find the index of the application to delete
    const appIndex = existingData.findIndex(app => app.name === name);

    // Step 3: Remove the application if it exists
    if (appIndex !== -1) {
        existingData.splice(appIndex, 1); // Remove the application from the array

        // Step 4: Write the updated array back to the file
        fs.writeFileSync(dataFilePath, JSON.stringify(existingData, null, 2));

        res.json({ status: 'resolved', message: 'Application deleted successfully!' });
    } else {
        res.json({ status: 'error', message: 'Application not found.' });
    }
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Node.js server is running on http://localhost:${PORT}`);
});
